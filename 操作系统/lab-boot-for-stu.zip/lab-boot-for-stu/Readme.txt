The first boot system

1)directly write to video memory 0xb8000

2)display msg: Loading

3) to run:
make run

4)in bochs: type c to continue
